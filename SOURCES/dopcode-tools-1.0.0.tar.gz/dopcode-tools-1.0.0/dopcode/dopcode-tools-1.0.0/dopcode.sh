#!/bin/sh

echo 'dopcode~ kyodae second floor!!!'
